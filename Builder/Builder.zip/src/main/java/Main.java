public class Main {
    public static void main(String[] args) {

        
        PratoBuilder pratoExecutivo1Builder = new PratoExecutivo1Builder();
        PratoDirector pratoDirector = new PratoDirector();
        Prato pratoExecutivo1 = pratoDirector.constructPrato(pratoExecutivo1Builder);
        System.out.println("Cardápio brasileiro:");
        pratoExecutivo1.display();

        System.out.println("\n-----------------------------\n");

        
        PratoBuilder pratoExecutivo2Builder = new PratoExecutivo2Builder();
        Prato pratoExecutivo2 = pratoDirector.constructPrato(pratoExecutivo2Builder);
        System.out.println("Cardápio italiano:");
        pratoExecutivo2.display();
    }
}