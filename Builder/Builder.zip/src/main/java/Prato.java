public class Prato {
    private String nome;
    private String tamanho;
    private String[] ingredientes;

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public void setIngredientes(String[] ingredientes) {
        this.ingredientes = ingredientes;
    }

    public void display() {
        System.out.println("Nome: " + nome);
        System.out.println("Tamanho: " + tamanho);
        System.out.println("Ingredientes: " + String.join(", ", ingredientes));
    }
}