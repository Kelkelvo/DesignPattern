public class PratoExecutivo1Builder implements PratoBuilder {
    private Prato prato;

    public PratoExecutivo1Builder() {
        this.prato = new Prato();
    }

    @Override
    public void buildNome() {
        prato.setNome("Prato executivo 1");  
    }

    @Override
    public void buildTamanho() {
        prato.setTamanho("serve 1 pessoa");  
    }

    @Override
    public void buildIngredientes() {
        prato.setIngredientes(new String[] {"arroz", "feijão", "carne", "salada"});  
    }

    @Override
    public Prato getResult() {
        return prato;
    }
}