public interface PratoBuilder {
    void buildNome();
    void buildTamanho();
    void buildIngredientes();
    Prato getResult();
}