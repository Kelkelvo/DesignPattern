public class PratoDirector {

    public Prato constructPrato(PratoBuilder builder) {
        builder.buildNome();
        builder.buildTamanho();
        builder.buildIngredientes();
        return builder.getResult();
    }
}