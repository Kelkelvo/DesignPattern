public class PratoExecutivo2Builder implements PratoBuilder {
    private Prato prato;

    public PratoExecutivo2Builder() {
        this.prato = new Prato();
    }

    @Override
    public void buildNome() {
        prato.setNome("Prato executivo 2");  
    }

    @Override
    public void buildTamanho() {
        prato.setTamanho("serve 2 pessoas");  
    }

    @Override
    public void buildIngredientes() {
        prato.setIngredientes(new String[] {"macarrão", "almôndega", "queijo ralado"});  
    }

    @Override
    public Prato getResult() {
        return prato;
    }
}