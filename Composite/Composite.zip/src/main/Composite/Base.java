// Componente base
interface Cardapio {
    void exibir();
    double getPreco();
}

// Folha (parte individual)
class PratoSimples implements Cardapio {
    private final String nome;
    private final double preco;

    public PratoSimples(String nome, double preco) {
        this.nome = nome;
        this.preco = preco;
    }

    @Override
    public void exibir() {
        System.out.println("- " + nome + " (R$ " + preco + ")");
    }

    @Override
    public double getPreco() {
        return preco;
    }
}
