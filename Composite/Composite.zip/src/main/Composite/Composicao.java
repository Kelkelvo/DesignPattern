import java.util.ArrayList;
import java.util.List;

// Composição (parte composta)
class PratoComposto implements Cardapio {
    private final String nome;
    private final List<Cardapio> itens = new ArrayList<>();

    public PratoComposto(String nome) {
        this.nome = nome;
    }

    // Adicionar itens ao prato composto
    public void add(Cardapio item) {
        itens.add(item);
    }

    // Remover itens do prato composto
    public void remove(Cardapio item) {
        itens.remove(item);
    }

    @Override
    public void exibir() {
        System.out.println(nome + ":");
        for (Cardapio item : itens) {
            item.exibir();
        }
    }

    @Override
    public double getPreco() {
        double total = 0;
        for (Cardapio item : itens) {
            total += item.getPreco();
        }
        return total;
    }
}