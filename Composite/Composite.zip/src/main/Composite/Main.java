// Classe principal para testar o sistema de restaurante
public class Main {
    public static void main(String[] args) {
        // Criação de pratos simples (folhas)
        Cardapio salada = new PratoSimples("Salada", 12.00);
        Cardapio arroz = new PratoSimples("Arroz", 10.00);
        Cardapio bife = new PratoSimples("Bife com Fritas", 25.00);
        Cardapio sobremesa = new PratoSimples("Pudim", 8.00);

        // Criação de pratos compostos
        PratoComposto pratoExecutivo = new PratoComposto("Prato Executivo");
        pratoExecutivo.add(salada);
        pratoExecutivo.add(bife);
        pratoExecutivo.add(sobremesa);

        PratoComposto pratoDiretor = new PratoComposto("Prato Diretor");
        pratoDiretor.add(arroz);
        pratoDiretor.add(bife);
        pratoDiretor.add(sobremesa);

        // Criação do menu principal composto
        PratoComposto menuCompleto = new PratoComposto("Menu Completo");
        menuCompleto.add(pratoExecutivo);
        menuCompleto.add(pratoDiretor);

        // Exibir o menu completo e os preços
        menuCompleto.exibir();
        System.out.println("\nPreço total do Menu Completo: R$ " + menuCompleto.getPreco());
    }
}
