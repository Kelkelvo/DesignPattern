public interface Observer {
    void atualizar(String estado);
}
