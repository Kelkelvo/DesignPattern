public class Main {
    public static void main(String[] args) {
        StatusRestaurante statusRestaurante = new StatusRestaurante();

        
        DisplayRestaurante display1 = new DisplayRestaurante("Display 1");
        DisplayRestaurante display2 = new DisplayRestaurante("Display 2");

        
        statusRestaurante.adicionarObserver(display1);
        statusRestaurante.adicionarObserver(display2);

       
        statusRestaurante.setEstado("Preparando Prato Principal");
        statusRestaurante.setEstado("Prato Principal Pronto");
        statusRestaurante.setEstado("Servindo Prato Principal");
        statusRestaurante.setEstado("Aguardando Novo Pedido");
    }
}
