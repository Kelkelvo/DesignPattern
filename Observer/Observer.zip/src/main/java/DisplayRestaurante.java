public class DisplayRestaurante implements Observer {
    private String nome;

    public DisplayRestaurante(String nome) {
        this.nome = nome;
    }

   
    public void atualizar(String estado) {
        System.out.println(nome + " atualizado com o status: " + estado);
    }
}
